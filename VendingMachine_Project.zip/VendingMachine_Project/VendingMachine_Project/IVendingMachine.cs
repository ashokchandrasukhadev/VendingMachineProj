﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_Project
{
    public interface IVendingMachine
    {
        decimal CheckCoinValue(CoinProperties prop);
        string CustomerSelectedItem(string selectedItem);
        string CheckItemAmount(string item, decimal updatedBalance);
    }
}

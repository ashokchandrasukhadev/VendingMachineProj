﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_Project
{
    class Constants
    {
        public const int nickelsWeight = 2;
        public const int dimesWeight = 3;
        public const int quartersWeight = 4;
        public const int penniesWeight = 1;

        public const int nickelSize = 2;
        public const int dimesSize = 4;
        public const int quartersSize = 5;
        public const int penniesSize = 1;

        public const string nickelValue = "0.05";
        public const string dimesValue = "0.1";
        public const string quartersValue = "0.25";
        public const string penniesValue = "0.01";

        
    }
}

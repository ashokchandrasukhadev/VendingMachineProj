﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_Project
{
    public class Program
    {
        static void Main(string[] args)
        {
            // Coin Insertion
            Console.WriteLine("Insert Coin..!");
            Common commonClass = new Common();
            decimal customerUpdatedBalance = commonClass.CoinAcceptance();
            Console.WriteLine("Your updated balance is " + customerUpdatedBalance);
            //Product Selection
            Console.WriteLine("Please select a Product..");
            string getProduct = commonClass.SelectProduct();
            Console.WriteLine("Please collect your Product.." + getProduct);
            Console.WriteLine("Thank You");
            Console.ReadLine();
        }
    }
}

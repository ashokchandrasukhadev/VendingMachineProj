﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_Project
{
    public class Common
    {
        private readonly IVendingMachine _vendingMachine;
        IVendingMachine vendingMachine;
        public Common()
        {
            _vendingMachine = vendingMachine;
        }
        public decimal CoinAcceptance()
        {
            CoinProperties properties = new CoinProperties();
            properties.CoinSize = 2; properties.CoinWeight = 3;
            decimal updatedBalance = _vendingMachine.CheckCoinValue(properties);
            return updatedBalance;
        }

        public string SelectProduct()
        {
            string productSelected = string.Empty;
            List<string> itemsInMachine = new List<string> { "Cola", "Chips", "Candy" };

            Console.WriteLine("Items Available" + itemsInMachine);
            Console.WriteLine("PLease select an item..");
            foreach (var itemSelected in itemsInMachine)
            {
                productSelected = _vendingMachine.CustomerSelectedItem(itemSelected);
            }
            return productSelected;
        }
    }

    public class CoinProperties
    {
        public int CoinSize { get; set; }
        public int CoinWeight { get; set; }
        public string CoinValue { get; set; }
    }

    public class CustomerAccount
    {
        public decimal Balance { get; set; }
    }
}

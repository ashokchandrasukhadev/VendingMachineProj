﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace VendingMachine_Project
{
    class VendingMachineImplementation : IVendingMachine
    {
        CustomerAccount customerAccount = new CustomerAccount();
        decimal finalBalance = 0;
        string item = string.Empty;
        decimal updatedBalance = 0;
        public decimal CheckCoinValue(CoinProperties prop)
        {
            try
            {
                if ((prop.CoinSize == Constants.penniesSize) && (prop.CoinWeight == Constants.penniesWeight))
                {
                    //Throw Message
                    Console.WriteLine("Penniess coins are not accepted..");
                }
                else if (prop.CoinSize == Constants.nickelSize && prop.CoinWeight == Constants.nickelsWeight)
                {
                    prop.CoinValue = Constants.nickelValue;
                }
                else if (prop.CoinSize == Constants.dimesSize && prop.CoinWeight == Constants.dimesWeight)
                {
                    prop.CoinValue = Constants.dimesValue;
                }
                else if (prop.CoinSize == Constants.quartersSize && prop.CoinWeight == Constants.quartersWeight)
                {
                    prop.CoinValue = Constants.quartersValue;
                }

                if (prop.CoinValue != null && prop.CoinValue != "")
                {
                    finalBalance = AddToCustomerAccount(prop.CoinValue);
                }

            }
            catch (Exception)
            {

                throw;
            }
            return finalBalance;

        }

        public decimal AddToCustomerAccount(string coinValue)
        {
            decimal coinAmount = Convert.ToDecimal(coinValue);
            customerAccount.Balance = customerAccount.Balance + coinAmount;
            updatedBalance = customerAccount.Balance;
            return updatedBalance;
        }

        public string CheckItemAmount(string item, decimal updatedBalance)
        {
            decimal balanceNeeded = 0;
            if (item == "Cola")
            {
                if (updatedBalance == Convert.ToDecimal(1))
                {
                    return item;
                }
                else
                {
                    balanceNeeded = Convert.ToDecimal(1) - updatedBalance;
                    Console.WriteLine("Please deposit remaining balance" + balanceNeeded);
                }

            }
            if (item == "Chips")
            {
                if (updatedBalance == Convert.ToDecimal(0.50))
                {
                    return item;
                }
                else
                {
                    balanceNeeded = Convert.ToDecimal(0.50) - updatedBalance;
                    Console.WriteLine("Please deposit remaining balance" + balanceNeeded);
                }

            }
            if (item == "Candy")
            {
                if (updatedBalance == Convert.ToDecimal(0.65))
                {
                    return item;
                }
                else
                {
                    balanceNeeded = Convert.ToDecimal(0.65) - updatedBalance;
                    Console.WriteLine("Please deposit remaining balance" + balanceNeeded);
                }

            }
            return item;
        }


        public string CustomerSelectedItem(string itemSelected)
        {
            if (itemSelected == "Cola")
            {
                Console.WriteLine("Please deposit 1$");
            }
            else if (itemSelected == "Chips")
            {
                Console.WriteLine("Please deposit 0.5$ ");
            }
            else
            {
                Console.WriteLine("Please deposit 0.65$ ");
            }

            item = itemSelected;
            item = CheckItemAmount(item, updatedBalance);
            return item;
        }
    }
}
